package sintactico;

import java.io.*;

import lexico.Simbolo;

public class TablaSimbolos {

	private Simbolo[] simbolos;
	private int apu;

	public TablaSimbolos() {
		apu = 0;
		simbolos = new Simbolo[100];
	}

	public boolean setSimbolo(String nombre, String valor, int tipo) {

		if (this.busqueda(nombre)!= -1){
			simbolos[apu] = new Simbolo(nombre, valor, tipo);
			apu++;
			return true;
		}
		else{
			
			return false;
		}
	}

	public boolean setSimbolo(String nombre, String valor, int tipo, int posicion) {

		if (this.busqueda(nombre) != -1){
		simbolos[posicion] = new Simbolo(nombre, valor, tipo);
		return true;
		}
		
		else{
			return false;
		}
	}

	public Simbolo getSimbolo() {

		return simbolos[apu - 1];

	}

	public Simbolo getSimbolo(int posicion) {

		return simbolos[posicion];

	}

	public int busqueda(String Nombre) {

		for (int i = 0; i < apu; i++) {

			if ((simbolos[i].getNombre()).equals(Nombre)) {
				return i;

			}

		}
		return -1;
	}

	public boolean modifica(String nombre, String nuevoNombre,
			String nuevoValor, int nuevoTipo) {

		int pos = busqueda(nombre);

		if (pos != -1) {
			setSimbolo(nuevoNombre, nuevoValor, nuevoTipo, pos);
			return true;
		} else {
			return false;
		}
	}

	public static void main(String args[]) throws IOException {

		TablaSimbolos tabla = new TablaSimbolos();
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int n;
		System.out.println("¿Cuantos elementos deseas agregar?");
		n = Integer.parseInt(in.readLine());

		String nombre;
		String valor;
		int tipo;

		for (int i = 0; i < n; i++) {
			System.out.println("Dame el nombre del simbolo: ");
			nombre = in.readLine();
			System.out.println("Dame el valor del simbolo: ");
			valor = in.readLine();
			System.out.println("Dame el tipo del simbolo: ");
			tipo = Integer.parseInt(in.readLine());
			tabla.setSimbolo(nombre, valor, tipo);
		}

		System.out.println("¿Qué deseas hacer?");
		do {
			System.out
					.println("1 Buscar un simbolo\n2 Modificar un registro\n3 Salir\n\n");
			n = Integer.parseInt(in.readLine());

			if (n == 1) {
				System.out.println("Dame el nombre a buscar");

				int resp = tabla.busqueda(in.readLine());

				if (resp == -1) {
					System.out.println("Simbolo no encontrado");
				} else {
					Simbolo sim = tabla.getSimbolo(resp);
					System.out.println(sim.getNombre());
					System.out.println(sim.getTipo());
					System.out.println(sim.getValor());
				}
			}

			else if (n == 2) {
				System.out.println("Dame el nombre a buscar");

				String nom = in.readLine();

				System.out.println("Dame el nombre del simbolo: ");
				nombre = in.readLine();
				System.out.println("Dame el valor del simbolo: ");
				valor = in.readLine();
				System.out.println("Dame el tipo del simbolo: ");
				tipo = Integer.parseInt(in.readLine());
				tabla.setSimbolo(nombre, valor, tipo);
				boolean resp = tabla.modifica(nom, nombre, valor, tipo);

				if (!resp) {
					System.out.println("Simbolo no encontrado");
				} else {

				}
			}
			System.out.println("¿Deseas continuar?\n 1.-Si\t2.-\tNo\n");
			n = Integer.parseInt(in.readLine());
		} while (n == 1);
	}

}
